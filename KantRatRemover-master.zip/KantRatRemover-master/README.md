# KantRatRemover
Should fully remove kant's rat from your computer
Go over to https://github.com/NyanCatForEver/KantRatRemover, its the orignal one :)